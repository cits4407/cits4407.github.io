#!/bin/bash

# Author: Arran Stewart
#
# Maze quality control script

# You can set these Bash options if desired -- see discussions from class.
# set -u
# set -e

usage() {
  # shellcheck disable=SC2059
  p () { printf "${PURPLE}"; }
  # shellcheck disable=SC2059
  nf () { printf "${NOFORMAT}"; }
  cat <<EOF
Usage: $(basename "${BASH_SOURCE[0]}")

Validates a maze supplied on standard input,
printing "yes" if the maze is valid, and
"no" if it is invalid.

Available options:
--help      Print this help and exit
EOF
}

setup_colors() {
  if [[ -t 2 ]] && [[ -z "${NO_COLOR-}" ]] && [[ "${TERM-}" != "dumb" ]]; then
    # shellcheck disable=SC2034
    NOFORMAT='\033[0m' RED='\033[0;31m' GREEN='\033[0;32m' ORANGE='\033[0;33m'
    BLUE='\033[0;34m' PURPLE='\033[0;35m' CYAN='\033[0;36m' YELLOW='\033[1;33m';
  else
    # shellcheck disable=SC2034
    NOFORMAT='' RED='' GREEN='' ORANGE='' BLUE='' PURPLE='' CYAN='' YELLOW=''
  fi
}

main () {
  # validate args
  if [ "$#" -eq 1 ] && [ "$1" = "--help" ] ; then
    usage;
    exit;
  elif [ "$#" -ne 0 ] ; then
    printf >&2 "${RED}Error:${NOFORMAT} Expected 0 args; got %s. See \"usage\" below.\n" "$#"
    usage;
    exit 1;
  fi

  # The following line will *usually* be fine; but will fail if, for instance,
  # the file /tmp/tmp.txt already exists and you don't have write permissions
  # for it.
  #
  # A more reliable way of creating a temporary file is to use the "mktemp" command:
  #   tmpfile_name="$(mktemp)"
  #   cat > $tmpfile_name
  cat > /tmp/tmp.txt
  
  # There are various faster alternatives to using "head" and "tail" --
  # for instance, using "sed" and "awk" -- but the following method
  # is probably the simplest to understand.
  second_line="$(head -n 2 /tmp/tmp.txt | tail -n 1)"
  second_last_line="$(tail -n 2 /tmp/tmp.txt | head -n 1)"

  # The following tests use *substring expansion*, a type of
  # parameter expansion: see
  # https://www.gnu.org/software/bash/manual/html_node/Shell-Parameter-Expansion.html
  # (Or just Google "find the first character of a variable" to find
  # many example uses of substring expansion.)
  #
  # It would also be possible to use "cut" to extract portions of
  # a string, but that is fairly slow (as it involves invoking an
  # external program), whereas substring expansion is quite fast.
  # (In a simple program like this, the difference isn't really
  # appreciable; in a program where portions of a string were being
  # extracted in a loop that ran thousands of times, it probably
  # would be.)

  if [ "${second_line:0:1}" != " " ] ; then
    echo no
    exit
  fi

  if [ "${second_last_line: -1}" != " " ] ; then
    echo no
  else
    echo yes
  fi
}

# setup colors and run main
setup_colors
main "${@}"

