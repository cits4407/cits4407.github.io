#!/bin/bash

# Author: Arran Stewart
#
# Maze quality control script

# You can set these Bash options if desired -- see discussions from class.
# set -u
# set -e

usage() {
  # shellcheck disable=SC2059
  p () { printf "${PURPLE}"; }
  # shellcheck disable=SC2059
  nf () { printf "${NOFORMAT}"; }
  cat <<EOF
Usage: $(basename "${BASH_SOURCE[0]}")

Validates a maze supplied on standard input,
printing "yes" if the maze is valid, and
"no" if it is invalid.

Available options:
--help      Print this help and exit
EOF
}

setup_colors() {
  if [[ -t 2 ]] && [[ -z "${NO_COLOR-}" ]] && [[ "${TERM-}" != "dumb" ]]; then
    # shellcheck disable=SC2034
    NOFORMAT='\033[0m' RED='\033[0;31m' GREEN='\033[0;32m' ORANGE='\033[0;33m'
    BLUE='\033[0;34m' PURPLE='\033[0;35m' CYAN='\033[0;36m' YELLOW='\033[1;33m';
  else
    # shellcheck disable=SC2034
    NOFORMAT='' RED='' GREEN='' ORANGE='' BLUE='' PURPLE='' CYAN='' YELLOW=''
  fi
}

## Helper functions for maze-solving ##


# Check if we've already visited a position.
# Arguments: x position and y position.
# Exits with success (exit code 0) if we
# have visited the location, or non-zero
# if we haven't.
has_been_visited () {
  grep -q "^$1 $2$" "$visited_file"
}

# Get the sign (plus or minus) of a number.
# Arguments: a number
# Prints to standard output either 1 or -1
sign () {
  echo "$(( $1 < 0 ? -1 : 1 ))"; 
}

# Get the absolute value of a number.
# Arguments: a number
# Prints the absolute value to standard output.
abs () {
  echo "$(( $1 * $(sign "$1") ))"
}

# Print to standard output a list of neighbouring cells to visit.
# Parameters: cur_x and cur_y.
#
# For each neighbouring cell we can move to,
# a line is printed, containing the x and y coordinates
# of the cell, separated by a space.
#
# Rules for what are valid neighbours:
# - x and y must never go outside the bounds of the
#   maze
# - our current position isn't a valid "neighbour"
# - we can't move diagonally
# - we can't move to somewhere already visited
# - we can't move into a wall
print_neighbours () {
  local cur_x cur_y x y
  cur_x=$1
  cur_y=$2

  for ((y = cur_y - 1; y <= cur_y + 1; y += 1)) ; do
    local cur_line="${lines[$y]}"
    for ((x = cur_x - 1; x <= cur_x + 1; x += 1)) ; do

      # skip out-of-bounds cells
      if ((x < 0 || y < 0 || x >= maze_width || y >= maze_height)); then continue; fi

      # skip cells we've visited
      if has_been_visited $x $y ; then continue; fi

      # skip the case where x and y are just our current position
      if ((x == cur_x && y == cur_y )); then continue; fi

      # skip cases where we'd be moving diagonally
      # (manhattan distance 2)
      local x_diff=$((x - cur_x))
      local y_diff=$((y - cur_y))
      local manhattan_dist=$(( $(abs $x_diff) + $(abs $y_diff) ))
      if (( manhattan_dist == 2 )); then continue; fi

      # skip cells that are walls
      local cur_char="${cur_line:$x:1}"
      if [ "$cur_char" == '#' ] ; then continue; fi

      # if still here, output position
      echo $x $y
    done
  done
}

# for use in debugging: show maze and our current position
# (as a full stop)
dump_maze () {
  echo
  local i=0
  declare -p cur_x cur_y
  for line in "${lines[@]}" ; do
    if ((i != cur_y)) ; then
      echo "> $line"
    elif ((cur_x == 0)); then
      echo "> .${line:1}"
    else
      local x_minus_1=$((cur_x - 1))
      echo "> ${line:0:x_minus_1}.${line:cur_x}"
    fi
    ((i += 1))
  done
  echo
}


# The main "workhorse" routine used to solve a maze.
# Does a recursive depth-first search (i.e. uses the
# call stack to permit back-tracking.)
#
# Arguments: current x and y position.
#
# Exits with success (exit code 0) if we reached the goal,
# failure (exit code 1) if no move is possible.
search () {
  local cur_x cur_y
  cur_x="$1"
  cur_y="$2"

  # to debug -- uncomment this line
  #dump_maze >&2

  # mark position as visited
  echo "$cur_x" "$cur_y" >> "$visited_file"

  # if we've reached goal, success
  if (( cur_x == desired_x && cur_y == desired_y )) ; then
    return 0
  fi

  declare -a neighbours
  readarray -t neighbours < <(print_neighbours "$cur_x" "$cur_y")

  # if no neighbours, that means we can't move
  # (dead end, or everywhere visited) - exit with failure
  if (( ${#neighbours[@]} == 0 )) ; then
    return 1
  fi
  
  # else try each neighbour in turn
  for new_pos in "${neighbours[@]}" ; do
    # don't quote new_pos - let it expand to two words
    #   shellcheck disable=SC2086
    if search $new_pos ; then
      return 0
    fi 
  done 

  return 1
}

main () {
  # validate args
  if [ "$#" -eq 1 ] && [ "$1" = "--help" ] ; then
    usage;
    exit;
  elif [ "$#" -ne 0 ] ; then
    printf >&2 "${RED}Error:${NOFORMAT} Expected 0 args; got %s. See \"usage\" below.\n" "$#"
    usage;
    exit 1;
  fi

  set -u

  # Completing this script successfully likely will require some
  # research into maze-solving and features available in
  # Bash.

  # We make use of the "readarray" command available in Bash 4.1,
  # and declare several helper functions (above):
  #
  # - has_been_visited
  # - sign
  # - abs
  # - print_neighbours
  # - dump_maze (used for debugging)
  # - search

  # Recall that by default, variables are global;
  # so unless we declare a variable using the "local"
  # keyword, we can access it from any function.
  #
  # In this solution, the lines of the maze, and data
  # like the height and width of the maze, are
  # put into global variables.
  # In Bash, it is *not possible* to pass an array
  # as a parameter, so declaring it as a global variable
  # is the only option.

  # read input lines into an array
  readarray -t lines < <(cat)

  # height in characters
  maze_height="${#lines[@]}"

  # width in characters
  first_line="${lines[0]}"
  maze_width="${#first_line}"
  
  # start at col 0, row 1
  local cur_x=0
  local cur_y=1

  # goal is to get to last col,
  # second-last row
  desired_x=$((maze_width - 1))
  desired_y=$((maze_height - 2))

  # Every time we visit a position, we'll just append a line to
  # this file; to see if we've already visited a position, we can just grep
  # it. (See "has_been_visited".)
  #
  # Creating the file in /dev/shm probably would speed things up
  # a bit -- e.g. we could write
  #     visited_file="$(mktemp -p /dev/shm/)"
  # -- as /dev/shm is a view onto an "in-memory" file system, and
  # should therefore be quicker than disk.
  visited_file=/tmp/visited
  cat /dev/null > $visited_file

  # invoke search()
  if search $cur_x $cur_y ; then
    echo yes
  else
    echo no
  fi
}


# setup colors and run main
setup_colors
main "${@}"

