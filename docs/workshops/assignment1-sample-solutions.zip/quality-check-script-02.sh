#!/bin/bash

# Author: Arran Stewart
#
# Maze quality control script

# You can set these Bash options if desired -- see discussions from class.
# set -u
# set -e

usage() {
  # shellcheck disable=SC2059
  p () { printf "${PURPLE}"; }
  # shellcheck disable=SC2059
  nf () { printf "${NOFORMAT}"; }
  cat <<EOF
Usage: $(basename "${BASH_SOURCE[0]}") num_cols num_rows

Validates a maze supplied on standard input,
printing "yes" if the maze is valid, and
"no" if it is invalid.

Available options:
--help      Print this help and exit
EOF
}

setup_colors() {
  if [[ -t 2 ]] && [[ -z "${NO_COLOR-}" ]] && [[ "${TERM-}" != "dumb" ]]; then
    # shellcheck disable=SC2034
    NOFORMAT='\033[0m' RED='\033[0;31m' GREEN='\033[0;32m' ORANGE='\033[0;33m'
    BLUE='\033[0;34m' PURPLE='\033[0;35m' CYAN='\033[0;36m' YELLOW='\033[1;33m';
  else
    # shellcheck disable=SC2034
    NOFORMAT='' RED='' GREEN='' ORANGE='' BLUE='' PURPLE='' CYAN='' YELLOW=''
  fi
}

main () {
  # validate args
  if [ "$#" -eq 1 ] && [ "$1" = "--help" ] ; then
    usage;
    exit;
  elif [ "$#" -ne 2 ] ; then
    printf >&2 "${RED}Error:${NOFORMAT} Expected 2 args; got %s. See \"usage\" below.\n" "$#"
    usage;
    exit 1;
  fi

  # get expected rows and cols in terms of characters
  expected_cols=$(($1 * 2 + 1))
  expected_rows=$(($2 * 2 + 1))

  num_rows=0

  while IFS= read -r line; do

    # The length of a string in Bash can be gotten
    # by using parameter expansion - see
    # https://www.gnu.org/software/bash/manual/html_node/Shell-Parameter-Expansion.html
    # (or just Google "length of a string in Bash").
    row_width="${#line}";

    # A shorter version of the following line is:
    #  ((num_rows += 1)) or ((num_rows++))
    # Putting the whole assignment within double parentheses
    # is often easier to read than using a $ to expand the
    # right-hand side of the assignment.
    ((num_rows = num_rows + 1))

    if (( row_width != expected_cols )) ; then
      echo no
      exit
    fi
  done
  
  if (( num_rows != expected_rows )) ; then
    echo no
  else
    echo yes
  fi
}

# setup colors and run main
setup_colors
main "${@}"

