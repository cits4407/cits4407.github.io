#!/usr/bin/env bash

if (( $# != 1 )) ; then
  echo >&2 Expected 1 argument, a .csv file of data
  exit 1
fi

set -euo pipefail

csv_file=$1

num_holes="$(wc -l < $csv_file)"

longest_lived="$(sort -r -n -t ',' -k 2 $csv_file  | head -n 1)"

IFS=',' read -r size lifetime <<< "$longest_lived"

cat <<EOF
---
title: Black hole report for Aperture Science
author: Jacob J. Intern
---

# Introduction

Results of experiments with micro-black holes are presented
below.

# Experiment details

- No. of black holes created: $num_holes

The longest-lived black hole had diameter $size nm
and a lifetime of $lifetime ns.

EOF







