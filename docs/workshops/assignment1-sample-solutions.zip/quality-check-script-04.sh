#!/bin/bash

# Author: Arran Stewart
#
# Maze quality control script

# You can set these Bash options if desired -- see discussions from class.
# set -u
# set -e

usage() {
  # shellcheck disable=SC2059
  p () { printf "${PURPLE}"; }
  # shellcheck disable=SC2059
  nf () { printf "${NOFORMAT}"; }
  cat <<EOF
Usage: $(basename "${BASH_SOURCE[0]}")

Validates a maze supplied on standard input,
printing "yes" if the maze is valid, and
"no" if it is invalid.

Available options:
--help      Print this help and exit
EOF
}

setup_colors() {
  if [[ -t 2 ]] && [[ -z "${NO_COLOR-}" ]] && [[ "${TERM-}" != "dumb" ]]; then
    # shellcheck disable=SC2034
    NOFORMAT='\033[0m' RED='\033[0;31m' GREEN='\033[0;32m' ORANGE='\033[0;33m'
    BLUE='\033[0;34m' PURPLE='\033[0;35m' CYAN='\033[0;36m' YELLOW='\033[1;33m';
  else
    # shellcheck disable=SC2034
    NOFORMAT='' RED='' GREEN='' ORANGE='' BLUE='' PURPLE='' CYAN='' YELLOW=''
  fi
}

main () {
  # validate args
  if [ "$#" -eq 1 ] && [ "$1" = "--help" ] ; then
    usage;
    exit;
  elif [ "$#" -ne 0 ] ; then
    printf >&2 "${RED}Error:${NOFORMAT} Expected 0 args; got %s. See \"usage\" below.\n" "$#"
    usage;
    exit 1;
  fi

  tempfile="/tmp/tmp.txt"
  cat > $tempfile

  # check the first line: should be all hashes
  # We grep for a character that *isn't* a hash.
  if head -n 1 $tempfile | grep -q '[^#]' ; then
    echo no
    exit
  fi

  # check the last line: should also be all hashes
  # We grep for a character that *isn't* a hash.
  if tail -n 1 $tempfile | grep -q '[^#]' ; then
    echo no
    exit
  fi

  # check the first column/"west" wall is correct:
  # we already know the first line is correct, and the
  # start of the second line is a space; so we need only check
  # the third-through-last lines, and ensure they all start with  
  # a hash.
  
  # "!" at the start of a pipeline negates its exit value.
  if ! tail -n +3 $tempfile | grep -q '^#' ; then
    echo no
    exit
  fi

  # check the last column/"east" wall is correct:
  # We already know the last line is correct, and
  # the second-last line ends with a space; so we
  # need only check the ends of the first through to
  # third-last lines, and ensure they all end with
  # a hash. 

  if ! head -n -2 $tempfile | grep -q '#$' ; then
    echo no
    exit
  fi

  # If we're still here, maze is ok
  echo yes
}

# setup colors and run main
setup_colors
main "${@}"

